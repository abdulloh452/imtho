


let text1 = document.querySelector('.text1')
let text2 = document.querySelector('.text2')
let plus = document.querySelector(".plus")
let minus = document.querySelector(".minus")
let bolu = document.querySelector(".bolu")
let kopayturu = document.querySelector(".kop")
let h1 =document.querySelector("h1")



plus.addEventListener('click', ()=>{
    let value1 = +text1.value
    let value2 = +text2.value
    h1.innerText = value1 + value2
}) 
minus.addEventListener('click', ()=>{
    let value1 = +text1.value
    let value2 = +text2.value
    h1.innerText = value1 - value2
}) 
bolu.addEventListener('click', ()=>{
    let value1 = +text1.value
    let value2 = +text2.value
    h1.innerText = value1 / value2
}) 
kopayturu.addEventListener('click', ()=>{
    let value1 = +text1.value
    let value2 = +text2.value
    h1.innerText = value1 * value2
}) 















































































































































